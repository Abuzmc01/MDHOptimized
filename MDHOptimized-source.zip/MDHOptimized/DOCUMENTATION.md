# MDHOptimized Documentation

Version 1.0.0 · Paper 1.20.1+ · Java 17+

## Contents
1. [Installation](#installation)
2. [Commands](#commands)
3. [Permissions](#permissions)
4. [Pre-generation](#pre-generation)
5. [Clear lag](#clear-lag)
6. [Redstone limiter](#redstone-limiter)
7. [Entity limits](#entity-limits)
8. [Alerts](#alerts)
9. [Full config.yml reference](#full-configyml-reference)
10. [FAQ](#faq)

---

## Installation
1. Put `MDHOptimized.jar` in `plugins/`.
2. Restart the server (don't use `/reload` or PlugMan).
3. Open `plugins/MDHOptimized/config.yml`, change what you need.
4. Run `/mdho reload`.

Running ClearLag or a similar plugin? Turn off its item clearing, or turn off `clear.enabled` here. Running both just clears everything twice.

---

## Commands
| Command | What it does |
|---|---|
| `/mdho` | Help |
| `/mdho status` | TPS, players, loaded chunks, total entities, throttled redstone chunks, time until next clear, pregen status |
| `/mdho scan [n]` | Lists the `n` chunks with the most entities (default 10, max 50), with X/Z and the top entity types |
| `/mdho alerts` | Last 30 alerts, newest first |
| `/mdho tp <number>` | Teleports you to the alert with that number (players only) |
| `/mdho clear [items\|mobs\|all] [world]` | Runs a clear right away, no countdown. Without `world` it clears all worlds except `clear.ignore-worlds` |
| `/mdho pregen start <world> <radius\|border> [x z]` | Starts pre-generation. Radius is in **blocks**. `border` uses the world border size and center |
| `/mdho pregen pause` / `resume` / `cancel` / `status` | Controls the running pregen |
| `/mdho reload` | Reloads config.yml and restarts the timers |

Aliases: `/mdhoptimized`, `/mdhopt`

---

## Permissions
| Permission | Default | Description |
|---|---|---|
| `mdhoptimized.admin` | op | Use every `/mdho` command |
| `mdhoptimized.alert` | op | Receive alerts in chat. Can be changed with `alerts.permission` |

---

## Pre-generation
```
/mdho pregen start world 5000
/mdho pregen start world 3000 1000 -2000
/mdho pregen start world_nether border
```
- Chunks are generated in a spiral from the center outwards.
- Before generating a chunk the plugin checks if it already exists. **Existing chunks are skipped**, so areas players already explored are not touched or regenerated.
- On Paper chunks are loaded async (`max-in-flight` at the same time). On Spigot it falls back to sync loading.
- Each generated chunk is unloaded again right after, so memory doesn't fill up.
- Pregen pauses by itself when TPS is below `pregen.min-tps` or when more than `pregen.pause-when-players-above` players are online, and continues when things are back to normal.
- Progress is written to `plugins/MDHOptimized/pregen.yml` every `save-interval-seconds`. After a restart it continues where it stopped.
- Only one pregen can run at a time.

Progress is printed in the console, for example:
```
[MDHO] Pregen: berjalan world 42.5% (baru: 18320, dilewati: 6210, sedang dimuat: 16) ETA ~37 menit
```
(*baru* = newly generated, *dilewati* = skipped because it already existed)

---

## Clear lag
Every `clear.interval-seconds` the plugin clears:
- dropped items older than `item-min-age-seconds`
- XP orbs (`experience-orbs`)
- arrows and other projectiles older than 30 seconds (`projectiles`)
- hostile mobs (`hostile-mobs`)
- passive mobs, only if `passive-mobs: true`

**Never removed:**
- players and NPCs (anything with the `NPC` metadata, e.g. Citizens)
- entities riding something or with passengers
- named entities (`ignore-named`)
- tamed animals (`ignore-tamed`)
- leashed mobs and persistent mobs (mobs that picked up items, name-tagged mobs, etc.)
- plugin mobs (`ignore-plugin-mobs`): mobs with plugin data or scoreboard tags, which covers MythicMobs, ModelEngine and most custom mob plugins
- every type in `ignore-types`

Warnings are sent at each second listed in `warnings`. Messages can be changed with `warning-message` and `done-message` (`{seconds}`, `{items}`, `{mobs}`, `{other}` are replaced).

---

## Redstone limiter
Per chunk and per `window-seconds` the plugin counts:
- redstone signal changes (`max-redstone-updates-per-chunk`)
- piston extends/retracts (`max-piston-moves-per-chunk`)
- hopper transfers (`max-hopper-moves-per-chunk`, only if `monitor-hoppers: true`)

When a chunk goes over a limit:
- `action: NOTIFY`: an alert is sent, nothing else.
- `action: THROTTLE`: an alert is sent and redstone, pistons and hoppers in that chunk are frozen for `throttle-seconds`. After that the machine works again. If it's still over the limit it gets throttled again.

Tips:
- Start with `NOTIFY` for a day, check the alerts, then switch to `THROTTLE` with limits that fit your server.
- Big legit farms (e.g. a large sorting system) can be allowed by raising the limits or adding the world to `ignore-worlds`.

---

## Entity limits
Checked when something spawns, using cached counts from the last scan, so it stays cheap.

**Mobs** (`mobs-per-chunk`, `mob-action`)
- Only spawn reasons in `limited-spawn-reasons` are limited (natural, spawners, breeding, eggs, iron golems, raids, ...).
- `CUSTOM` (plugins) and `COMMAND` are never limited, so MythicMobs, bosses and admin spawns keep working.
- `CANCEL_SPAWN` cancels the spawn, `NOTIFY` only alerts.

**Items** (`items-per-chunk`, `item-action`)
- Default is `NOTIFY`. `CANCEL_SPAWN` stops new drops in a full chunk, but that also means block drops or death drops in that chunk can disappear, so use it carefully.

---

## Alerts
Alerts go to the console (`alerts.console`) and to every player with `alerts.permission`.

| Alert | Triggered when |
|---|---|
| Item di tanah berlebih | more than `thresholds.items-per-chunk` items in one chunk |
| Mob berlebih | more than `thresholds.mobs-per-chunk` mobs in one chunk |
| Entity berlebih | more than `thresholds.entities-per-chunk` entities in one chunk |
| Hopper berlebih | more than `thresholds.hoppers-per-chunk` hoppers in one chunk |
| Tile entity berlebih | more than `thresholds.tile-entities-per-chunk` chests/furnaces/hoppers/etc. |
| Mesin redstone / Piston / Hopper berlebih | redstone limiter limit reached |
| Batas mob per chunk tercapai | entity limit reached |
| TPS rendah | TPS below `alerts.low-tps`, includes the heaviest chunk |

Every alert shows the world, block X/Z (center of the chunk) and chunk X/Z. The same alert at the same location is only repeated after `cooldown-seconds`.

Use `/mdho alerts` to see the list and `/mdho tp <number>` to go there. `/mdho tp 1` is always the newest.

Entity counts are refreshed every `scan-interval-seconds`. Tile entities are checked a few chunks per tick (`tile-scan-chunks-per-tick`) so the scan never causes a spike.

---

## Full config.yml reference

### General
| Key | Default | Description |
|---|---|---|
| `prefix` | `&8[&bMDHO&8] &r` | Message prefix, `&` color codes |

### alerts
| Key | Default | Description |
|---|---|---|
| `enabled` | `true` | Turn alerts on/off |
| `console` | `true` | Also print alerts in the console |
| `permission` | `mdhoptimized.alert` | Who gets alerts in-game |
| `cooldown-seconds` | `120` | Don't repeat the same alert at the same spot within this time |
| `scan-interval-seconds` | `30` | How often entities are counted |
| `low-tps` | `16.0` | Alert when TPS is below this |
| `thresholds.entities-per-chunk` | `200` | |
| `thresholds.items-per-chunk` | `300` | |
| `thresholds.mobs-per-chunk` | `80` | |
| `thresholds.tile-entities-per-chunk` | `300` | |
| `thresholds.hoppers-per-chunk` | `64` | |
| `scan-tile-entities` | `true` | Check hoppers / tile entities |
| `tile-scan-chunks-per-tick` | `40` | Chunks checked per tick during a tile scan |

### redstone
| Key | Default | Description |
|---|---|---|
| `enabled` | `true` | |
| `action` | `THROTTLE` | `NOTIFY` or `THROTTLE` |
| `window-seconds` | `1` | Counting window |
| `max-redstone-updates-per-chunk` | `800` | Per window |
| `max-piston-moves-per-chunk` | `150` | Per window |
| `monitor-hoppers` | `true` | Count hopper transfers |
| `max-hopper-moves-per-chunk` | `600` | Per window |
| `throttle-seconds` | `15` | How long a chunk stays frozen |
| `ignore-worlds` | `[]` | Worlds without redstone limits |

### entity-limit
| Key | Default | Description |
|---|---|---|
| `enabled` | `true` | |
| `mobs-per-chunk` | `60` | |
| `mob-action` | `CANCEL_SPAWN` | `NOTIFY` or `CANCEL_SPAWN` |
| `items-per-chunk` | `400` | |
| `item-action` | `NOTIFY` | `NOTIFY` or `CANCEL_SPAWN` |
| `limited-spawn-reasons` | natural, spawner, breeding, ... | Spawn reasons that count toward the limit |
| `ignore-worlds` | `[]` | |

### clear
| Key | Default | Description |
|---|---|---|
| `enabled` | `true` | |
| `interval-seconds` | `900` | Minimum 30 |
| `warnings` | `[60, 30, 10, 3]` | Seconds before the clear to warn |
| `broadcast` | `true` | Send warnings/result to all players |
| `warning-message` | | `{seconds}` |
| `done-message` | | `{items}`, `{mobs}`, `{other}` |
| `items` | `true` | |
| `item-min-age-seconds` | `30` | |
| `experience-orbs` | `true` | |
| `projectiles` | `true` | Only older than 30 seconds |
| `hostile-mobs` | `true` | |
| `passive-mobs` | `false` | |
| `ignore-named` | `true` | |
| `ignore-tamed` | `true` | |
| `ignore-plugin-mobs` | `true` | Skip mobs with plugin data / scoreboard tags |
| `ignore-types` | villagers, armor stands, frames, displays, bosses, ... | Bukkit entity type names |
| `ignore-worlds` | `[]` | |

### pregen
| Key | Default | Description |
|---|---|---|
| `shape` | `SQUARE` | `SQUARE` or `CIRCLE` |
| `chunks-per-tick` | `4` | New chunk requests per tick |
| `max-in-flight` | `16` | Max chunks loading at once |
| `min-tps` | `18.0` | Pause below this TPS |
| `pause-when-players-above` | `300` | Pause when more players are online |
| `save-interval-seconds` | `30` | How often progress is saved |
| `progress-interval-seconds` | `30` | How often progress is printed |

---

## FAQ

**Will clear lag delete my NPCs / holograms / MythicMobs bosses?**
No. Players, NPCs, armor stands, displays, item frames and mobs with plugin data are skipped. Bosses (Wither, Ender Dragon, Warden, Elder Guardian) are in `ignore-types` by default.

**A player's farm stopped working.**
Probably the redstone limiter in `THROTTLE` mode. Check `/mdho alerts` to see which chunk, then raise the limit or switch to `NOTIFY`.

**Pregen is very slow.**
It pauses when TPS is under `min-tps` or there are many players online. Run it at night, or raise `chunks-per-tick` / `max-in-flight` if your CPU has room.

**Does it work on Folia?**
No, Folia is not supported.

**Can I change the alert language?**
Clear lag messages can be changed in config.yml. Other messages are currently Indonesian only.
