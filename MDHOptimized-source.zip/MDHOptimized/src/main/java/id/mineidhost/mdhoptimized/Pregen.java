package id.mineidhost.mdhoptimized;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Pre-generate chunk berbentuk spiral dari titik tengah.
 * Chunk yang SUDAH ADA (pernah dikunjungi pemain / sudah di-generate) dilewati, tidak di-generate ulang.
 * Otomatis jeda kalau TPS turun / pemain terlalu banyak, progres disimpan dan dilanjutkan setelah restart.
 */
final class Pregen {
    private final MDHOptimized p;
    private String world; private int cx, cz, radius; private long index, total, generated, skipped;
    private boolean running, paused, asyncOk = true, tpsPaused;
    private final AtomicInteger inFlight = new AtomicInteger();
    private long startMs, startIndex, lastSave, lastProgress;

    Pregen(MDHOptimized p) { this.p = p; }

    private File file() { return new File(p.getDataFolder(), "pregen.yml"); }

    // ================= Spiral =================
    /** index (0-based) -> offset [dx, dz] spiral persegi dari tengah. */
    static int[] spiral(long i) {
        if (i == 0) return new int[]{0, 0};
        long n = i + 1;
        long k = (long) Math.ceil((Math.sqrt((double) n) - 1) / 2);
        long t = 2 * k + 1;
        long m = t * t;
        t = t - 1;
        if (n >= m - t) return new int[]{(int) (k - (m - n)), (int) -k};
        m -= t;
        if (n >= m - t) return new int[]{(int) -k, (int) (-k + (m - n))};
        m -= t;
        if (n >= m - t) return new int[]{(int) (-k + (m - n)), (int) k};
        return new int[]{(int) k, (int) (k - (m - n - t))};
    }

    // ================= Perintah =================
    void command(CommandSender s, String[] a) {
        String sub = a.length == 0 ? "status" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "start": start(s, a); break;
            case "pause": if (running) { paused = true; save(); s.sendMessage(p.msg("&ePregen dijeda.")); } else s.sendMessage(p.msg("&7Tidak ada pregen.")); break;
            case "resume": if (running) { paused = false; s.sendMessage(p.msg("&aPregen dilanjutkan.")); } else s.sendMessage(p.msg("&7Tidak ada pregen.")); break;
            case "cancel": if (running) { running = false; file().delete(); s.sendMessage(p.msg("&cPregen dibatalkan.")); } else s.sendMessage(p.msg("&7Tidak ada pregen.")); break;
            default: s.sendMessage(p.msg("&bPregen: &f" + statusLine()));
        }
    }

    private void start(CommandSender s, String[] a) {
        if (running) { s.sendMessage(p.msg("&cPregen sedang berjalan di " + world + ". /mdho pregen cancel dulu.")); return; }
        if (a.length < 3) { s.sendMessage(p.msg("&e/mdho pregen start <world> <radius blok|border> [x z]")); return; }
        World w = Bukkit.getWorld(a[1]);
        if (w == null) { s.sendMessage(p.msg("&cWorld '" + a[1] + "' tidak ditemukan.")); return; }
        int centerX = 0, centerZ = 0, radBlocks;
        if (a[2].equalsIgnoreCase("border")) {
            WorldBorder b = w.getWorldBorder();
            Location c = b.getCenter();
            centerX = c.getBlockX(); centerZ = c.getBlockZ();
            radBlocks = (int) Math.min(b.getSize() / 2, 100_000);
        } else {
            radBlocks = MDHOptimized.parseInt(a[2], -1);
            if (radBlocks <= 0) { s.sendMessage(p.msg("&cRadius tidak valid.")); return; }
        }
        if (a.length >= 5) { centerX = MDHOptimized.parseInt(a[3], 0); centerZ = MDHOptimized.parseInt(a[4], 0); }
        world = w.getName(); cx = centerX >> 4; cz = centerZ >> 4; radius = Math.max(1, (radBlocks + 15) >> 4);
        total = (2L * radius + 1) * (2L * radius + 1);
        index = 0; startIndex = 0; generated = 0; skipped = 0; running = true; paused = false; startMs = System.currentTimeMillis();
        save();
        s.sendMessage(p.msg("&aPregen dimulai: &f" + world + " &7radius &f" + radBlocks + " &7blok (" + total + " chunk) dari X:" + centerX + " Z:" + centerZ
                + ". &7Chunk yang sudah ada dilewati."));
    }

    String statusLine() {
        if (!running) return "tidak berjalan";
        double pct = total == 0 ? 100 : index * 100.0 / total;
        String state = paused ? "&edijeda" : tpsPaused ? "&ejeda otomatis (TPS/pemain)" : "&aberjalan";
        long el = Math.max(1, System.currentTimeMillis() - startMs);
        long done = index - startIndex;
        long eta = done <= 0 ? -1 : (long) ((total - index) * (el / (double) done) / 1000);
        return String.format(Locale.ROOT, "%s &f%s %.1f%% &7(baru: %d, dilewati: %d, sedang dimuat: %d)%s", state, world, pct, generated, skipped,
                inFlight.get(), eta >= 0 ? " &7ETA ~" + (eta / 60) + " menit" : "");
    }

    // ================= Tick =================
    void tick() {
        if (!running || paused) return;
        World w = Bukkit.getWorld(world);
        if (w == null) return;
        long now = System.currentTimeMillis();
        MDHOptimized.Settings s = p.cfg;
        if (now - lastSave > s.pgSaveSec * 1000L) { save(); lastSave = now; }
        if (now - lastProgress > s.pgProgressSec * 1000L) {
            lastProgress = now;
            Bukkit.getConsoleSender().sendMessage(p.msg("&7Pregen: " + statusLine()));
        }
        tpsPaused = p.tps() < s.pgMinTps || Bukkit.getOnlinePlayers().size() > s.pgMaxPlayers;
        if (tpsPaused) return;

        int started = 0, checks = 0;
        while (index < total && started < s.pgChunksPerTick && checks < 256 && inFlight.get() < s.pgMaxInFlight) {
            int[] d = spiral(index);
            checks++;
            if (s.pgCircle && (long) d[0] * d[0] + (long) d[1] * d[1] > (long) radius * radius) { index++; continue; }
            int x = cx + d[0], z = cz + d[1];
            index++;
            boolean exists;
            try { exists = w.isChunkGenerated(x, z); } catch (Throwable t) { exists = false; }
            if (exists) { skipped++; continue; }                  // sudah ada -> tidak di-generate ulang
            started++;
            load(w, x, z);
        }
        if (index >= total && inFlight.get() == 0) {
            running = false;
            file().delete();
            String done = p.msg("&aPregen selesai: &f" + world + " &7(baru: " + generated + ", dilewati: " + skipped + ")");
            Bukkit.getConsoleSender().sendMessage(done);
        }
    }

    private void load(World w, int x, int z) {
        if (asyncOk) {
            try {
                inFlight.incrementAndGet();
                w.getChunkAtAsync(x, z).whenComplete((c, err) -> Bukkit.getScheduler().runTask(p, () -> {
                    inFlight.decrementAndGet();
                    if (err == null) generated++;
                    try { w.unloadChunkRequest(x, z); } catch (Throwable ignored) {}
                }));
                return;
            } catch (Throwable t) {                               // bukan Paper: pakai cara sinkron
                inFlight.decrementAndGet();
                asyncOk = false;
            }
        }
        try { w.getChunkAt(x, z); generated++; w.unloadChunkRequest(x, z); } catch (Throwable ignored) {}
    }

    // ================= Simpan / lanjutkan =================
    void save() {
        if (!running) return;
        try {
            p.getDataFolder().mkdirs();
            YamlConfiguration y = new YamlConfiguration();
            y.set("world", world); y.set("cx", cx); y.set("cz", cz); y.set("radius", radius);
            y.set("index", Math.max(0, index - p.cfg.pgMaxInFlight));    // mundur sedikit: chunk yang masih dimuat diulang aman (akan dilewati)
            y.set("generated", generated); y.set("skipped", skipped); y.set("paused", paused);
            y.save(file());
        } catch (Exception e) {
            p.getLogger().warning("Gagal menyimpan pregen.yml: " + e.getMessage());
        }
    }

    void resumeIfSaved() {
        File f = file();
        if (!f.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        world = y.getString("world", null);
        if (world == null) return;
        cx = y.getInt("cx", 0); cz = y.getInt("cz", 0); radius = y.getInt("radius", 1);
        total = (2L * radius + 1) * (2L * radius + 1);
        index = y.getLong("index", 0); generated = y.getLong("generated", 0); skipped = y.getLong("skipped", 0);
        paused = y.getBoolean("paused", false);
        running = true; startIndex = index; startMs = System.currentTimeMillis() - 1;
        p.getLogger().info("Melanjutkan pregen " + world + " dari chunk ke-" + index + "/" + total);
    }
}
