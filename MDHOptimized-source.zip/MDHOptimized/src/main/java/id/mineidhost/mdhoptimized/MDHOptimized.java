package id.mineidhost.mdhoptimized;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * MDHOptimized - optimasi server Paper (MineIDHost).
 * Fitur: pre-generate chunk (skip chunk yang sudah ada), clear lag terjadwal, limit redstone/entity per chunk,
 * dan notifikasi lokasi masalah ke console + operator.
 */
public final class MDHOptimized extends JavaPlugin implements CommandExecutor, TabCompleter {

    Settings cfg;
    Alerts alerts;
    Monitor monitor;
    Cleaner cleaner;
    Pregen pregen;
    private final List<BukkitTask> tasks = new ArrayList<>();

    // TPS cadangan (kalau server bukan Paper)
    private long lastTickNanos = System.nanoTime();
    private double fallbackTps = 20.0;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        alerts = new Alerts(this);
        monitor = new Monitor(this);
        cleaner = new Cleaner(this);
        pregen = new Pregen(this);
        loadSettings();
        getServer().getPluginManager().registerEvents(monitor, this);
        PluginCommand cmd = getCommand("mdho");
        if (cmd != null) { cmd.setExecutor(this); cmd.setTabCompleter(this); }
        startTasks();
        pregen.resumeIfSaved();
        getLogger().info("MDHOptimized aktif. Ketik /mdho untuk bantuan.");
    }

    @Override
    public void onDisable() {
        stopTasks();
        if (pregen != null) pregen.save();
    }

    void loadSettings() {
        reloadConfig();
        cfg = new Settings(getConfig());
    }

    void startTasks() {
        stopTasks();
        // TPS cadangan: ukur 20 tick
        tasks.add(Bukkit.getScheduler().runTaskTimer(this, () -> {
            long now = System.nanoTime();
            double sec = (now - lastTickNanos) / 1e9;
            lastTickNanos = now;
            if (sec > 0) fallbackTps = Math.min(20.0, 20.0 / sec);
        }, 20L, 20L));
        long scan = Math.max(5, cfg.scanIntervalSec) * 20L;
        tasks.add(Bukkit.getScheduler().runTaskTimer(this, monitor::scanEntities, 100L, scan));
        if (cfg.scanTiles) tasks.add(Bukkit.getScheduler().runTaskTimer(this, monitor::tileScanStep, 200L, 1L));
        long win = Math.max(1, cfg.rsWindowSec) * 20L;
        tasks.add(Bukkit.getScheduler().runTaskTimer(this, monitor::endRedstoneWindow, win, win));
        tasks.add(Bukkit.getScheduler().runTaskTimer(this, cleaner::tickSecond, 20L, 20L));
        tasks.add(Bukkit.getScheduler().runTaskTimer(this, pregen::tick, 1L, 1L));
    }

    void stopTasks() {
        for (BukkitTask t : tasks) try { t.cancel(); } catch (Throwable ignored) {}
        tasks.clear();
    }

    double tps() {
        try {
            double[] t = Bukkit.getServer().getTPS();
            if (t != null && t.length > 0) return Math.min(20.0, t[0]);
        } catch (Throwable ignored) {}
        return fallbackTps;
    }

    static String color(String s) { return s == null ? "" : s.replace('&', '§'); }
    String msg(String s) { return color(cfg.prefix + s); }

    // ================= Command =================
    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("mdhoptimized.admin")) { s.sendMessage(msg("&cKamu tidak punya izin.")); return true; }
        String sub = a.length == 0 ? "help" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload":
                loadSettings(); startTasks();
                s.sendMessage(msg("&aConfig dimuat ulang."));
                return true;
            case "status":
                status(s); return true;
            case "scan":
                int n = a.length > 1 ? parseInt(a[1], 10) : 10;
                monitor.printTop(s, Math.max(1, Math.min(50, n)));
                return true;
            case "alerts":
                alerts.list(s); return true;
            case "tp":
                if (!(s instanceof Player)) { s.sendMessage(msg("&cHanya untuk pemain.")); return true; }
                if (a.length < 2) { s.sendMessage(msg("&e/mdho tp <nomor> &7(lihat /mdho alerts)")); return true; }
                alerts.teleport((Player) s, parseInt(a[1], -1));
                return true;
            case "clear":
                String what = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "all";
                int[] r = cleaner.clearNow(what, a.length > 2 ? a[2] : null);
                s.sendMessage(msg("&aDihapus: &f" + r[0] + " &7item, &f" + r[1] + " &7mob, &f" + r[2] + " &7lainnya."));
                return true;
            case "pregen":
                pregen.command(s, Arrays.copyOfRange(a, 1, a.length));
                return true;
            default:
                help(s); return true;
        }
    }

    private void help(CommandSender s) {
        s.sendMessage(msg("&bMDHOptimized &7- perintah:"));
        s.sendMessage(color("&e/mdho status &7- TPS, entity, redstone, jadwal clear"));
        s.sendMessage(color("&e/mdho scan [n] &7- n chunk dengan entity terbanyak + koordinat"));
        s.sendMessage(color("&e/mdho alerts &7- daftar peringatan terakhir"));
        s.sendMessage(color("&e/mdho tp <nomor> &7- teleport ke lokasi peringatan"));
        s.sendMessage(color("&e/mdho clear [items|mobs|all] [world] &7- clear lag sekarang"));
        s.sendMessage(color("&e/mdho pregen start <world> <radius|border> [x z] &7- pre-generate (skip chunk yang sudah ada)"));
        s.sendMessage(color("&e/mdho pregen pause|resume|cancel|status"));
        s.sendMessage(color("&e/mdho reload &7- muat ulang config"));
    }

    private void status(CommandSender s) {
        int entities = 0, chunks = 0;
        for (World w : Bukkit.getWorlds()) { entities += w.getEntities().size(); chunks += w.getLoadedChunks().length; }
        s.sendMessage(msg("&bStatus server"));
        s.sendMessage(color(String.format(Locale.ROOT, "&7TPS: &f%.2f &7| Pemain: &f%d &7| Chunk dimuat: &f%d &7| Entity: &f%d",
                tps(), Bukkit.getOnlinePlayers().size(), chunks, entities)));
        s.sendMessage(color("&7Redstone dibatasi sementara: &f" + monitor.throttledCount() + " &7chunk | Aksi redstone: &f" + cfg.rsAction));
        s.sendMessage(color("&7Clear lag berikutnya: &f" + (cfg.clearEnabled ? cleaner.secondsLeft() + " detik" : "mati")));
        s.sendMessage(color("&7Pregen: &f" + pregen.statusLine()));
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("mdhoptimized.admin")) return out;
        if (a.length == 1) out.addAll(Arrays.asList("status", "scan", "alerts", "tp", "clear", "pregen", "reload"));
        else if (a.length == 2 && a[0].equalsIgnoreCase("clear")) out.addAll(Arrays.asList("items", "mobs", "all"));
        else if (a.length == 2 && a[0].equalsIgnoreCase("pregen")) out.addAll(Arrays.asList("start", "pause", "resume", "cancel", "status"));
        else if ((a.length == 3 && a[0].equalsIgnoreCase("pregen") && a[1].equalsIgnoreCase("start"))
                || (a.length == 3 && a[0].equalsIgnoreCase("clear"))) for (World w : Bukkit.getWorlds()) out.add(w.getName());
        else if (a.length == 4 && a[0].equalsIgnoreCase("pregen") && a[1].equalsIgnoreCase("start")) out.addAll(Arrays.asList("border", "100", "250", "500"));
        String last = a.length == 0 ? "" : a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }

    static int parseInt(String s, int d) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return d; } }

    static String typeName(Entity e) { try { return e.getType().name(); } catch (Throwable t) { return e.getClass().getSimpleName(); } }

    static Location center(World w, int cx, int cz) {
        int x = (cx << 4) + 8, z = (cz << 4) + 8;
        int y = 100;
        try { y = w.getHighestBlockYAt(x, z) + 1; } catch (Throwable ignored) {}
        return new Location(w, x + 0.5, y, z + 0.5);
    }

    // ================= Settings =================
    static final class Settings {
        final String prefix;
        // alerts
        final boolean alertsEnabled, alertConsole; final String alertPerm; final int alertCooldownSec, scanIntervalSec;
        final int thEntities, thItems, thMobs, thTiles, thHoppers; final double lowTps;
        final boolean scanTiles; final int tileChunksPerTick;
        // redstone
        final boolean rsEnabled; final int rsWindowSec, rsMaxUpdates, rsMaxPistons, rsMaxHopper, rsThrottleSec; final String rsAction; final boolean rsHopper;
        final Set<String> rsIgnoreWorlds;
        // entity limit
        final boolean limEnabled; final String limMobAction, limItemAction; final int limItems, limMobs; final Set<String> limReasons, limIgnoreWorlds;
        // clear
        final boolean clearEnabled, clearBroadcast, clearItems, clearXp, clearProjectiles, clearHostile, clearPassive, ignoreNamed, ignoreTamed, ignorePluginMobs;
        final int clearInterval, itemMinAgeSec; final List<Integer> warnings; final Set<String> ignoreTypes, clearIgnoreWorlds;
        final String warnMsg, doneMsg;
        // pregen
        final int pgChunksPerTick, pgMaxInFlight, pgMaxPlayers, pgSaveSec, pgProgressSec; final double pgMinTps; final boolean pgCircle;

        Settings(FileConfiguration c) {
            prefix = c.getString("prefix", "&8[&bMDHO&8] &r");
            alertsEnabled = c.getBoolean("alerts.enabled", true);
            alertConsole = c.getBoolean("alerts.console", true);
            alertPerm = c.getString("alerts.permission", "mdhoptimized.alert");
            alertCooldownSec = c.getInt("alerts.cooldown-seconds", 120);
            scanIntervalSec = c.getInt("alerts.scan-interval-seconds", 30);
            thEntities = c.getInt("alerts.thresholds.entities-per-chunk", 200);
            thItems = c.getInt("alerts.thresholds.items-per-chunk", 300);
            thMobs = c.getInt("alerts.thresholds.mobs-per-chunk", 80);
            thTiles = c.getInt("alerts.thresholds.tile-entities-per-chunk", 300);
            thHoppers = c.getInt("alerts.thresholds.hoppers-per-chunk", 64);
            lowTps = c.getDouble("alerts.low-tps", 16.0);
            scanTiles = c.getBoolean("alerts.scan-tile-entities", true);
            tileChunksPerTick = c.getInt("alerts.tile-scan-chunks-per-tick", 40);

            rsEnabled = c.getBoolean("redstone.enabled", true);
            rsWindowSec = c.getInt("redstone.window-seconds", 1);
            rsMaxUpdates = c.getInt("redstone.max-redstone-updates-per-chunk", 800);
            rsMaxPistons = c.getInt("redstone.max-piston-moves-per-chunk", 150);
            rsHopper = c.getBoolean("redstone.monitor-hoppers", true);
            rsMaxHopper = c.getInt("redstone.max-hopper-moves-per-chunk", 600);
            rsAction = c.getString("redstone.action", "THROTTLE").toUpperCase(Locale.ROOT);
            rsThrottleSec = c.getInt("redstone.throttle-seconds", 15);
            rsIgnoreWorlds = lower(c.getStringList("redstone.ignore-worlds"));

            limEnabled = c.getBoolean("entity-limit.enabled", true);
            limMobAction = c.getString("entity-limit.mob-action", "CANCEL_SPAWN").toUpperCase(Locale.ROOT);
            limItemAction = c.getString("entity-limit.item-action", "NOTIFY").toUpperCase(Locale.ROOT);
            limItems = c.getInt("entity-limit.items-per-chunk", 400);
            limMobs = c.getInt("entity-limit.mobs-per-chunk", 60);
            List<String> rs = c.getStringList("entity-limit.limited-spawn-reasons");
            limReasons = rs.isEmpty() ? new HashSet<>(Arrays.asList("NATURAL", "SPAWNER", "BREEDING", "EGG", "DISPENSE_EGG", "BUILD_IRONGOLEM", "VILLAGE_DEFENSE", "JOCKEY", "MOUNT", "PATROL", "RAID", "SLIME_SPLIT", "REINFORCEMENTS"))
                    : upper(rs);
            limIgnoreWorlds = lower(c.getStringList("entity-limit.ignore-worlds"));

            clearEnabled = c.getBoolean("clear.enabled", true);
            clearInterval = Math.max(30, c.getInt("clear.interval-seconds", 900));
            List<Integer> w = c.getIntegerList("clear.warnings");
            warnings = w.isEmpty() ? Arrays.asList(60, 30, 10, 3) : w;
            clearBroadcast = c.getBoolean("clear.broadcast", true);
            warnMsg = c.getString("clear.warning-message", "&eSemua item di tanah akan dihapus dalam &c{seconds} detik&e!");
            doneMsg = c.getString("clear.done-message", "&aClear lag: &f{items} &aitem, &f{mobs} &amob, &f{other} &alainnya dihapus.");
            clearItems = c.getBoolean("clear.items", true);
            itemMinAgeSec = c.getInt("clear.item-min-age-seconds", 30);
            clearXp = c.getBoolean("clear.experience-orbs", true);
            clearProjectiles = c.getBoolean("clear.projectiles", true);
            clearHostile = c.getBoolean("clear.hostile-mobs", true);
            clearPassive = c.getBoolean("clear.passive-mobs", false);
            ignoreNamed = c.getBoolean("clear.ignore-named", true);
            ignoreTamed = c.getBoolean("clear.ignore-tamed", true);
            ignorePluginMobs = c.getBoolean("clear.ignore-plugin-mobs", true);
            List<String> it = c.getStringList("clear.ignore-types");
            ignoreTypes = it.isEmpty() ? new HashSet<>(Arrays.asList("VILLAGER", "WANDERING_TRADER", "ARMOR_STAND", "ITEM_FRAME", "GLOW_ITEM_FRAME",
                    "PAINTING", "ITEM_DISPLAY", "BLOCK_DISPLAY", "TEXT_DISPLAY", "INTERACTION", "TRIDENT", "ENDER_DRAGON", "WITHER", "ELDER_GUARDIAN", "WARDEN", "SHULKER"))
                    : upper(it);
            clearIgnoreWorlds = lower(c.getStringList("clear.ignore-worlds"));

            pgChunksPerTick = Math.max(1, c.getInt("pregen.chunks-per-tick", 4));
            pgMaxInFlight = Math.max(1, c.getInt("pregen.max-in-flight", 16));
            pgMinTps = c.getDouble("pregen.min-tps", 18.0);
            pgMaxPlayers = c.getInt("pregen.pause-when-players-above", 300);
            pgSaveSec = c.getInt("pregen.save-interval-seconds", 30);
            pgProgressSec = c.getInt("pregen.progress-interval-seconds", 30);
            pgCircle = "CIRCLE".equalsIgnoreCase(c.getString("pregen.shape", "SQUARE"));
        }

        static Set<String> lower(List<String> l) { Set<String> s = new HashSet<>(); for (String x : l) s.add(x.toLowerCase(Locale.ROOT)); return s; }
        static Set<String> upper(List<String> l) { Set<String> s = new HashSet<>(); for (String x : l) s.add(x.toUpperCase(Locale.ROOT)); return s; }
    }
}
