package id.mineidhost.mdhoptimized;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.text.SimpleDateFormat;
import java.util.*;

/** Notifikasi masalah ke console dan pemain dengan permission (default: operator). */
final class Alerts {
    private final MDHOptimized p;
    private final Map<String, Long> cooldown = new HashMap<>();
    private final LinkedList<Entry> recent = new LinkedList<>();

    static final class Entry {
        final long time; final String world; final int cx, cz; final String text;
        Entry(long t, String w, int cx, int cz, String text) { time = t; world = w; this.cx = cx; this.cz = cz; this.text = text; }
    }

    Alerts(MDHOptimized p) { this.p = p; }

    /** @param key jenis masalah (dipakai untuk cooldown per lokasi) */
    void raise(String key, World w, int cx, int cz, String text) {
        if (!p.cfg.alertsEnabled) return;
        long now = System.currentTimeMillis();
        String ck = key + "|" + w.getName() + "|" + cx + "|" + cz;
        Long last = cooldown.get(ck);
        if (last != null && now - last < p.cfg.alertCooldownSec * 1000L) return;
        cooldown.put(ck, now);
        if (cooldown.size() > 5000) cooldown.entrySet().removeIf(e -> now - e.getValue() > p.cfg.alertCooldownSec * 1000L);

        recent.addFirst(new Entry(now, w.getName(), cx, cz, text));
        while (recent.size() > 30) recent.removeLast();
        int bx = (cx << 4) + 8, bz = (cz << 4) + 8;
        String line = p.msg("&c⚠ " + text + " &7di &f" + w.getName() + " &7X:&f" + bx + " &7Z:&f" + bz
                + " &8(chunk " + cx + "," + cz + ") &7→ &e/mdho tp 1");
        if (p.cfg.alertConsole) Bukkit.getConsoleSender().sendMessage(line);
        for (Player pl : Bukkit.getOnlinePlayers()) if (pl.hasPermission(p.cfg.alertPerm)) pl.sendMessage(line);
    }

    void raiseGlobal(String key, String text) {
        if (!p.cfg.alertsEnabled) return;
        long now = System.currentTimeMillis();
        Long last = cooldown.get(key);
        if (last != null && now - last < p.cfg.alertCooldownSec * 1000L) return;
        cooldown.put(key, now);
        String line = p.msg("&c⚠ " + text);
        if (p.cfg.alertConsole) Bukkit.getConsoleSender().sendMessage(line);
        for (Player pl : Bukkit.getOnlinePlayers()) if (pl.hasPermission(p.cfg.alertPerm)) pl.sendMessage(line);
    }

    void list(CommandSender s) {
        if (recent.isEmpty()) { s.sendMessage(p.msg("&aBelum ada peringatan.")); return; }
        SimpleDateFormat f = new SimpleDateFormat("HH:mm:ss");
        s.sendMessage(p.msg("&bPeringatan terakhir:"));
        int i = 1;
        for (Entry e : recent) {
            s.sendMessage(MDHOptimized.color("&e" + i++ + ". &7[" + f.format(new Date(e.time)) + "] &f" + e.text + " &7di &f" + e.world
                    + " &7X:&f" + ((e.cx << 4) + 8) + " &7Z:&f" + ((e.cz << 4) + 8)));
        }
        s.sendMessage(MDHOptimized.color("&7Teleport: &e/mdho tp <nomor>"));
    }

    void teleport(Player pl, int idx) {
        if (idx < 1 || idx > recent.size()) { pl.sendMessage(p.msg("&cNomor tidak valid. Lihat /mdho alerts")); return; }
        Entry e = recent.get(idx - 1);
        World w = Bukkit.getWorld(e.world);
        if (w == null) { pl.sendMessage(p.msg("&cWorld " + e.world + " tidak ditemukan.")); return; }
        Location l = MDHOptimized.center(w, e.cx, e.cz);
        pl.teleport(l);
        pl.sendMessage(p.msg("&aTeleport ke &f" + e.world + " " + l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ()));
    }
}
