package id.mineidhost.mdhoptimized;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.*;

import java.util.Locale;

/** Clear lag terjadwal dengan peringatan, dan clear manual. */
final class Cleaner {
    private final MDHOptimized p;
    private int left = -1;

    Cleaner(MDHOptimized p) { this.p = p; }

    int secondsLeft() { return left < 0 ? p.cfg.clearInterval : left; }

    void tickSecond() {
        if (!p.cfg.clearEnabled) { left = -1; return; }
        if (left < 0 || left > p.cfg.clearInterval) left = p.cfg.clearInterval;
        left--;
        if (p.cfg.clearBroadcast && p.cfg.warnings.contains(left))
            broadcast(p.cfg.warnMsg.replace("{seconds}", String.valueOf(left)));
        if (left <= 0) {
            int[] r = clearNow("all", null);
            if (p.cfg.clearBroadcast)
                broadcast(p.cfg.doneMsg.replace("{items}", "" + r[0]).replace("{mobs}", "" + r[1]).replace("{other}", "" + r[2]));
            Bukkit.getConsoleSender().sendMessage(p.msg("&7Clear lag otomatis: " + r[0] + " item, " + r[1] + " mob, " + r[2] + " lainnya."));
            left = p.cfg.clearInterval;
        }
    }

    private void broadcast(String m) {
        String line = p.msg(m);
        for (Player pl : Bukkit.getOnlinePlayers()) pl.sendMessage(line);
    }

    /** @return [items, mobs, lainnya] */
    int[] clearNow(String what, String worldName) {
        boolean items = what.equals("all") || what.equals("items");
        boolean mobs = what.equals("all") || what.equals("mobs");
        int[] r = new int[3];
        for (World w : Bukkit.getWorlds()) {
            if (worldName != null && !w.getName().equalsIgnoreCase(worldName)) continue;
            if (worldName == null && p.cfg.clearIgnoreWorlds.contains(w.getName().toLowerCase(Locale.ROOT))) continue;
            for (Entity e : w.getEntities()) {
                int kind = classify(e, items, mobs);
                if (kind < 0) continue;
                e.remove();
                r[kind]++;
            }
        }
        return r;
    }

    /** -1 = jangan dihapus, 0 = item, 1 = mob, 2 = lainnya */
    int classify(Entity e, boolean items, boolean mobs) {
        MDHOptimized.Settings s = p.cfg;
        if (e instanceof Player || !e.isValid()) return -1;
        if (s.ignoreTypes.contains(MDHOptimized.typeName(e))) return -1;
        if (e.isInsideVehicle() || !e.getPassengers().isEmpty()) return -1;
        if (e.hasMetadata("NPC")) return -1;                                   // Citizens & plugin NPC
        if (s.ignoreNamed && e.getCustomName() != null) return -1;

        if (e instanceof Item) {
            if (!items || !s.clearItems) return -1;
            return e.getTicksLived() >= s.itemMinAgeSec * 20 ? 0 : -1;
        }
        if (e instanceof ExperienceOrb) return items && s.clearXp ? 2 : -1;
        if (e instanceof Projectile) return items && s.clearProjectiles && e.getTicksLived() > 600 ? 2 : -1;

        if (e instanceof Mob) {
            if (!mobs) return -1;
            Mob m = (Mob) e;
            if (s.ignoreTamed && e instanceof Tameable && ((Tameable) e).isTamed()) return -1;
            try { if (m.isLeashed()) return -1; } catch (Throwable ignored) {}
            try { if (!m.getRemoveWhenFarAway()) return -1; } catch (Throwable ignored) {}   // mob persisten (nama tag, diambil item, dll)
            if (s.ignorePluginMobs) {
                try { if (!e.getPersistentDataContainer().isEmpty()) return -1; } catch (Throwable ignored) {} // MythicMobs/ModelEngine/dll
                try { if (!e.getScoreboardTags().isEmpty()) return -1; } catch (Throwable ignored) {}
            }
            boolean hostile = e instanceof Enemy;
            if (hostile && s.clearHostile) return 1;
            if (!hostile && s.clearPassive) return 1;
            return -1;
        }
        return -1;
    }
}
