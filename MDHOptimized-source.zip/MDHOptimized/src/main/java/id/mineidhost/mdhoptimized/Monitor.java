package id.mineidhost.mdhoptimized;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;

import java.util.*;

/** Pantau redstone, entity per chunk, tile entity, dan TPS. */
final class Monitor implements Listener {
    private final MDHOptimized p;

    // counter redstone per window: world -> chunkKey -> [redstone, piston, hopper]
    private final Map<World, Map<Long, int[]>> rs = new IdentityHashMap<>();
    // chunk yang sedang dibatasi: world -> chunkKey -> sampai kapan (ms)
    private final Map<World, Map<Long, Long>> throttled = new IdentityHashMap<>();
    // cache jumlah entity per chunk dari scan terakhir: world -> chunkKey -> [items, mobs]
    private final Map<World, Map<Long, int[]>> counts = new IdentityHashMap<>();

    // scan tile entity bertahap
    private final ArrayDeque<Chunk> tileQueue = new ArrayDeque<>();
    private long nextTileScan = 0;

    Monitor(MDHOptimized p) { this.p = p; }

    static long key(int cx, int cz) { return ((long) cx << 32) ^ (cz & 0xffffffffL); }
    static int kx(long k) { return (int) (k >> 32); }
    static int kz(long k) { return (int) k; }

    // ================= Redstone =================
    private boolean rsActive(World w) { return p.cfg.rsEnabled && !p.cfg.rsIgnoreWorlds.contains(w.getName().toLowerCase(Locale.ROOT)); }

    private int[] rsCounter(World w, int cx, int cz) {
        return rs.computeIfAbsent(w, x -> new HashMap<>()).computeIfAbsent(key(cx, cz), x -> new int[3]);
    }

    private boolean isThrottled(World w, int cx, int cz) {
        Map<Long, Long> m = throttled.get(w);
        if (m == null || m.isEmpty()) return false;
        Long until = m.get(key(cx, cz));
        if (until == null) return false;
        if (until < System.currentTimeMillis()) { m.remove(key(cx, cz)); return false; }
        return true;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRedstone(BlockRedstoneEvent e) {
        Block b = e.getBlock(); World w = b.getWorld();
        if (!rsActive(w)) return;
        int cx = b.getX() >> 4, cz = b.getZ() >> 4;
        if (isThrottled(w, cx, cz)) { e.setNewCurrent(e.getOldCurrent()); return; }
        rsCounter(w, cx, cz)[0]++;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) { piston(e.getBlock(), () -> e.setCancelled(true)); }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) { piston(e.getBlock(), () -> e.setCancelled(true)); }

    private void piston(Block b, Runnable cancel) {
        World w = b.getWorld();
        if (!rsActive(w)) return;
        int cx = b.getX() >> 4, cz = b.getZ() >> 4;
        if (isThrottled(w, cx, cz)) { cancel.run(); return; }
        rsCounter(w, cx, cz)[1]++;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHopper(InventoryMoveItemEvent e) {
        if (!p.cfg.rsEnabled || !p.cfg.rsHopper) return;
        Location l;
        try { l = e.getSource().getLocation(); } catch (Throwable t) { return; }
        if (l == null || l.getWorld() == null) return;
        World w = l.getWorld();
        if (!rsActive(w)) return;
        int cx = l.getBlockX() >> 4, cz = l.getBlockZ() >> 4;
        if (isThrottled(w, cx, cz)) { e.setCancelled(true); return; }
        rsCounter(w, cx, cz)[2]++;
    }

    /** Dipanggil setiap akhir window: cek chunk yang melebihi batas. */
    void endRedstoneWindow() {
        boolean throttle = "THROTTLE".equals(p.cfg.rsAction);
        long until = System.currentTimeMillis() + p.cfg.rsThrottleSec * 1000L;
        for (Map.Entry<World, Map<Long, int[]>> we : rs.entrySet()) {
            World w = we.getKey();
            for (Map.Entry<Long, int[]> ce : we.getValue().entrySet()) {
                int[] c = ce.getValue();
                String why = null;
                if (c[0] > p.cfg.rsMaxUpdates) why = "Mesin redstone berlebih (&c" + c[0] + "&f update/" + p.cfg.rsWindowSec + "s)";
                else if (c[1] > p.cfg.rsMaxPistons) why = "Piston berlebih (&c" + c[1] + "&f gerakan/" + p.cfg.rsWindowSec + "s)";
                else if (c[2] > p.cfg.rsMaxHopper) why = "Hopper berlebih (&c" + c[2] + "&f transfer/" + p.cfg.rsWindowSec + "s)";
                if (why == null) continue;
                long k = ce.getKey();
                if (throttle) {
                    throttled.computeIfAbsent(w, x -> new HashMap<>()).put(k, until);
                    why += " &7- dihentikan " + p.cfg.rsThrottleSec + " detik";
                }
                p.alerts.raise("redstone", w, kx(k), kz(k), "&f" + why);
            }
        }
        rs.clear();
    }

    int throttledCount() {
        long now = System.currentTimeMillis(); int n = 0;
        for (Map<Long, Long> m : throttled.values()) for (long u : m.values()) if (u > now) n++;
        return n;
    }

    // ================= Entity =================
    static boolean isMob(Entity e) { return e instanceof Mob; }

    /** Scan semua entity per world, isi cache, kirim peringatan. */
    void scanEntities() {
        MDHOptimized.Settings s = p.cfg;
        counts.clear();
        for (World w : Bukkit.getWorlds()) {
            Map<Long, int[]> m = new HashMap<>();
            Map<Long, Map<String, Integer>> types = new HashMap<>();
            for (Entity e : w.getEntities()) {
                if (e instanceof Player) continue;
                Location l = e.getLocation();
                long k = key(l.getBlockX() >> 4, l.getBlockZ() >> 4);
                int[] c = m.computeIfAbsent(k, x -> new int[3]);
                c[2]++;
                if (e instanceof Item) c[0]++;
                else if (isMob(e)) c[1]++;
                types.computeIfAbsent(k, x -> new HashMap<>()).merge(MDHOptimized.typeName(e), 1, Integer::sum);
            }
            counts.put(w, m);
            for (Map.Entry<Long, int[]> ce : m.entrySet()) {
                int[] c = ce.getValue();
                String why = null;
                if (c[0] > s.thItems) why = "Item di tanah berlebih (&c" + c[0] + "&f)";
                else if (c[1] > s.thMobs) why = "Mob berlebih (&c" + c[1] + "&f)";
                else if (c[2] > s.thEntities) why = "Entity berlebih (&c" + c[2] + "&f)";
                if (why != null) p.alerts.raise("entity", w, kx(ce.getKey()), kz(ce.getKey()), "&f" + why + " &7" + top(types.get(ce.getKey()), 3));
            }
        }
        double tps = p.tps();
        if (tps < s.lowTps) {
            String where = topChunkText();
            p.alerts.raiseGlobal("lowtps", String.format(Locale.ROOT, "&fTPS rendah: &c%.1f&f.%s", tps, where.isEmpty() ? "" : " Chunk terberat: " + where));
        }
    }

    private String topChunkText() {
        World bw = null; long bk = 0; int best = 0;
        for (Map.Entry<World, Map<Long, int[]>> we : counts.entrySet())
            for (Map.Entry<Long, int[]> ce : we.getValue().entrySet())
                if (ce.getValue()[2] > best) { best = ce.getValue()[2]; bw = we.getKey(); bk = ce.getKey(); }
        if (bw == null) return "";
        return "&f" + bw.getName() + " X:" + ((kx(bk) << 4) + 8) + " Z:" + ((kz(bk) << 4) + 8) + " &7(" + best + " entity)";
    }

    static String top(Map<String, Integer> m, int n) {
        if (m == null) return "";
        List<Map.Entry<String, Integer>> l = new ArrayList<>(m.entrySet());
        l.sort((a, b) -> b.getValue() - a.getValue());
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < Math.min(n, l.size()); i++) { if (i > 0) sb.append(", "); sb.append(l.get(i).getKey()).append(" x").append(l.get(i).getValue()); }
        return sb.append("]").toString();
    }

    private boolean limitActive(World w) { return p.cfg.limEnabled && !p.cfg.limIgnoreWorlds.contains(w.getName().toLowerCase(Locale.ROOT)); }

    private int[] cached(World w, int cx, int cz) {
        return counts.computeIfAbsent(w, x -> new HashMap<>()).computeIfAbsent(key(cx, cz), x -> new int[3]);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCreatureSpawn(CreatureSpawnEvent e) {
        Location l = e.getLocation(); World w = l.getWorld();
        if (w == null || !limitActive(w)) return;
        if (!(e.getEntity() instanceof Mob)) return;
        String reason;
        try { reason = e.getSpawnReason().name(); } catch (Throwable t) { reason = "UNKNOWN"; }
        if (!p.cfg.limReasons.contains(reason)) return;     // CUSTOM/COMMAND (plugin, MythicMobs, admin) tidak dibatasi
        int cx = l.getBlockX() >> 4, cz = l.getBlockZ() >> 4;
        int[] c = cached(w, cx, cz);
        if (c[1] >= p.cfg.limMobs * 8 / 10) {                // dekat batas: hitung ulang langsung
            int live = 0;
            try { for (Entity en : w.getChunkAt(cx, cz).getEntities()) if (isMob(en)) live++; } catch (Throwable t) { live = c[1]; }
            c[1] = live;
        }
        if (c[1] >= p.cfg.limMobs) {
            if ("CANCEL_SPAWN".equals(p.cfg.limMobAction)) e.setCancelled(true);
            p.alerts.raise("moblimit", w, cx, cz, "&fBatas mob per chunk tercapai (&c" + c[1] + "/" + p.cfg.limMobs + "&f, " + reason + ")"
                    + ("CANCEL_SPAWN".equals(p.cfg.limMobAction) ? " &7- spawn dibatalkan" : ""));
            return;
        }
        c[1]++;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onItemSpawn(ItemSpawnEvent e) {
        Location l = e.getLocation(); World w = l.getWorld();
        if (w == null || !limitActive(w)) return;
        int cx = l.getBlockX() >> 4, cz = l.getBlockZ() >> 4;
        int[] c = cached(w, cx, cz);
        c[0]++;
        if (c[0] > p.cfg.limItems) {
            if ("CANCEL_SPAWN".equals(p.cfg.limItemAction)) e.setCancelled(true);
            p.alerts.raise("itemlimit", w, cx, cz, "&fItem di tanah melebihi batas (&c" + c[0] + "/" + p.cfg.limItems + "&f)"
                    + ("CANCEL_SPAWN".equals(p.cfg.limItemAction) ? " &7- drop baru dibatalkan" : ""));
        }
    }

    // ================= Tile entity (hopper, chest, dll) =================
    void tileScanStep() {
        if (!p.cfg.scanTiles) return;
        if (tileQueue.isEmpty()) {
            long now = System.currentTimeMillis();
            if (now < nextTileScan) return;
            nextTileScan = now + Math.max(60, p.cfg.scanIntervalSec * 4) * 1000L;
            for (World w : Bukkit.getWorlds()) Collections.addAll(tileQueue, w.getLoadedChunks());
            return;
        }
        int budget = Math.max(1, p.cfg.tileChunksPerTick);
        while (budget-- > 0 && !tileQueue.isEmpty()) {
            Chunk c = tileQueue.poll();
            BlockState[] tiles;
            try { tiles = c.getTileEntities(false); }            // Paper: tanpa snapshot (ringan)
            catch (Throwable t) { try { tiles = c.getTileEntities(); } catch (Throwable t2) { continue; } }
            if (tiles.length <= Math.min(p.cfg.thTiles, p.cfg.thHoppers)) continue;
            int hoppers = 0;
            for (BlockState bs : tiles) if (bs.getClass().getSimpleName().contains("Hopper")) hoppers++;
            World w = c.getWorld();
            if (hoppers > p.cfg.thHoppers)
                p.alerts.raise("hopper", w, c.getX(), c.getZ(), "&fHopper berlebih (&c" + hoppers + "&f di 1 chunk)");
            else if (tiles.length > p.cfg.thTiles)
                p.alerts.raise("tiles", w, c.getX(), c.getZ(), "&fTile entity berlebih (&c" + tiles.length + "&f chest/hopper/furnace dll)");
        }
    }

    // ================= /mdho scan =================
    void printTop(CommandSender s, int n) {
        class Row { World w; long k; int total, items, mobs; Map<String, Integer> t = new HashMap<>(); }
        List<Row> rows = new ArrayList<>();
        for (World w : Bukkit.getWorlds()) {
            Map<Long, Row> m = new HashMap<>();
            for (Entity e : w.getEntities()) {
                if (e instanceof Player) continue;
                Location l = e.getLocation();
                long k = key(l.getBlockX() >> 4, l.getBlockZ() >> 4);
                Row r = m.computeIfAbsent(k, x -> { Row nr = new Row(); nr.w = w; nr.k = x; return nr; });
                r.total++;
                if (e instanceof Item) r.items++; else if (isMob(e)) r.mobs++;
                r.t.merge(MDHOptimized.typeName(e), 1, Integer::sum);
            }
            rows.addAll(m.values());
        }
        rows.sort((a, b) -> b.total - a.total);
        s.sendMessage(p.msg("&bTop " + n + " chunk (entity terbanyak):"));
        for (int i = 0; i < Math.min(n, rows.size()); i++) {
            Row r = rows.get(i);
            s.sendMessage(MDHOptimized.color("&e" + (i + 1) + ". &f" + r.w.getName() + " &7X:&f" + ((kx(r.k) << 4) + 8) + " &7Z:&f" + ((kz(r.k) << 4) + 8)
                    + " &7- &c" + r.total + " &7entity (&f" + r.items + " &7item, &f" + r.mobs + " &7mob) " + top(r.t, 3)));
        }
        if (rows.isEmpty()) s.sendMessage(MDHOptimized.color("&7Tidak ada entity."));
    }

}
